# SPACE SemAE -> HASOS pipeline trace: `space_hasos_full_e20`

| Time | Stage | Status | Details |
| --- | --- | --- | --- |
| 2026-06-10T01:16:39+0700 | `pipeline_start` | **ok** | `python`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python, `cwd`=/home/llm/llm/tesing, `model`=checkpoints/space_full_11402x20_stable_resume_e7/space_full_11402x20_stable_resume_e7_20_model.pt, `sentencepiece`=data/sentencepiece/space_unigram_32k.model, `num_shards`=4 |
| 2026-06-10T01:16:39+0700 | `artifact:source_hasos_json` | **ok** | `path`=data/hasos/hasos_summ.source.json, `exists`=True, `bytes`=5247941, `sha256`=ae60c7a6583408712a4d16b757b6729478e6c612f757f3c5bebac37836845b52 |
| 2026-06-10T01:16:39+0700 | `artifact:model_checkpoint` | **ok** | `path`=checkpoints/space_full_11402x20_stable_resume_e7/space_full_11402x20_stable_resume_e7_20_model.pt, `exists`=True, `bytes`=106191291, `sha256`=75f995e5e69ecabe57967c7cff6f2ff6b6cd3b50f2d450348fff1ab875156186 |
| 2026-06-10T01:16:39+0700 | `artifact:taxonomy_tsv` | **ok** | `path`=/home/llm/llm/tesing/data/hasos/aspect_taxonomy.tsv, `exists`=True, `bytes`=8765, `sha256`=ec9e612be6fd20dcddb506e8781e2e24f5146f92d6681639ddf9ae34b394e30f |
| 2026-06-10T01:16:39+0700 | `prepare_hasos` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/prepare_hasos.py --input-json data/hasos/hasos_summ.source.json --output-json /home/llm/llm/tesing/data/hasos/hasos_summ.json --taxonomy-json /home/llm/llm/tesing/data/hasos/aspect_taxonomy.json --seeds-dir /home/llm/llm/tesing/data/seeds_hasos |
| 2026-06-10T01:16:39+0700 | `prepare_hasos` | **ok** | `returncode`=0, `seconds`=0.02, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_prepare_hasos.log |
| 2026-06-10T01:16:39+0700 | `validate_hasos` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/validate_hasos.py --data /home/llm/llm/tesing/data/hasos/hasos_summ.json --taxonomy /home/llm/llm/tesing/data/hasos/aspect_taxonomy.json --seeds-dir /home/llm/llm/tesing/data/seeds_hasos |
| 2026-06-10T01:16:39+0700 | `validate_hasos` | **ok** | `returncode`=0, `seconds`=0.04, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_validate_hasos.log |
| 2026-06-10T01:16:39+0700 | `artifact:space_sentencepiece_exact_gate` | **ok** | `path`=data/sentencepiece/space_unigram_32k.model, `exists`=True, `bytes`=792838, `sha256`=842bd72f7bbc02bbbbe1301715346f3be5938815c96f3011ac6715d42c6ddb7e |
| 2026-06-10T01:16:39+0700 | `inference` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/run_space_hasos_aspect_parallel.py --model checkpoints/space_full_11402x20_stable_resume_e7/space_full_11402x20_stable_resume_e7_20_model.pt --run_id space_hasos_full_e20 --num_shards 4 --gpu 0 --max_tokens 40 --sentiment_split |
| 2026-06-10T01:19:17+0700 | `inference` | **ok** | `returncode`=0, `seconds`=158.0, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_inference.log |
| 2026-06-10T01:19:17+0700 | `export_lines` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/export_space_hasos_lines.py --run_id space_hasos_full_e20 |
| 2026-06-10T01:19:17+0700 | `export_lines` | **ok** | `returncode`=0, `seconds`=0.26, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_export_lines.log |
| 2026-06-10T01:19:17+0700 | `summarize_outputs` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/summarize_aspect_outputs.py --run_id space_hasos_full_e20 |
| 2026-06-10T01:19:17+0700 | `summarize_outputs` | **ok** | `returncode`=0, `seconds`=0.05, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_summarize_outputs.log |
| 2026-06-10T01:19:17+0700 | `score_outputs` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/score_semae_run.py --run_id space_hasos_full_e20 --bert_score |
| 2026-06-10T01:19:28+0700 | `score_outputs` | **ok** | `returncode`=0, `seconds`=11.15, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_score_outputs.log |
| 2026-06-10T01:19:28+0700 | `build_pptx` | **start** | `command`=/home/llm/miniconda3/envs/vllm_qwen312/bin/python /home/llm/llm/tesing/scripts/build_space_hasos_report_pptx.py --run_id space_hasos_full_e20 |
| 2026-06-10T01:19:28+0700 | `build_pptx` | **ok** | `returncode`=0, `seconds`=0.05, `log`=/home/llm/llm/tesing/logs/space_hasos_full_e20_build_pptx.log |
| 2026-06-10T01:19:28+0700 | `pipeline_complete` | **ok** | `outputs`=/home/llm/llm/tesing/outputs/space_hasos_full_e20 |
